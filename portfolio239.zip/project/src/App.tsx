import React, { useState, useEffect } from 'react';
import { ChevronRight, ExternalLink, Github, Menu, X, ArrowUp, Mail, Phone, MapPin, Download } from 'lucide-react';

interface Project {
  id: string;
  title: string;
  category: string;
  description: string;
  image: string;
  tags: string[];
  demoUrl?: string;
  githubUrl?: string;
}

const projects: Project[] = [
  {
    id: '1',
    title: 'Real-Time Energy Optimization System',
    category: 'Engineering Project',
    description: 'Designed and implemented a real-time energy optimization system using SEPIC converter and integrated energy storage for hybrid wind-solar microgrids.',
    image: 'https://images.pexels.com/photos/9875441/pexels-photo-9875441.jpeg?auto=compress&cs=tinysrgb&w=800',
    tags: ['Power Systems', 'Renewable Energy', 'SEPIC Converter', 'Energy Storage'],
    demoUrl: '#',
    githubUrl: '#'
  },
  {
    id: '2',
    title: 'IoT Smart Quality Monitoring System',
    category: 'IoT Project',
    description: 'Developed an IoT-based smart quality monitoring system with real-time data collection and analysis capabilities.',
    image: 'https://images.pexels.com/photos/8566526/pexels-photo-8566526.jpeg?auto=compress&cs=tinysrgb&w=800',
    tags: ['IoT', 'Embedded Systems', 'Real-time Monitoring', 'Data Analytics'],
    demoUrl: '#',
    githubUrl: '#'
  },
  {
    id: '3',
    title: 'PCB Design & Fabrication',
    category: 'Hardware Design',
    description: 'Professional PCB design and fabrication projects showcasing expertise in electronic circuit design and manufacturing.',
    image: 'https://images.pexels.com/photos/163100/circuit-circuit-board-resistor-computer-163100.jpeg?auto=compress&cs=tinysrgb&w=800',
    tags: ['PCB Design', 'Circuit Analysis', 'Hardware Development', 'Fabrication'],
    demoUrl: '#',
    githubUrl: '#'
  },
  {
    id: '4',
    title: 'Weather Report Application',
    category: 'Software Project',
    description: 'Developed a comprehensive weather reporting application with real-time weather data, forecasting, and interactive user interface for multiple locations.',
    image: 'https://images.pexels.com/photos/1118873/pexels-photo-1118873.jpeg?auto=compress&cs=tinysrgb&w=800',
    tags: ['Weather API', 'Real-time Data', 'User Interface', 'Location Services'],
    demoUrl: '#',
    githubUrl: '#'
  }
];

function App() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  const categories = ['All', 'Engineering Project', 'IoT Project', 'Hardware Design', 'Software Project'];

  const filteredProjects = selectedCategory === 'All' 
    ? projects 
    : projects.filter(project => project.category === selectedCategory);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };

    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('scroll', handleScroll);
    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDownloadResume = () => {
    const link = document.createElement('a');
    link.href = '/KISHORE ORG RESUME.docx';
    link.download = 'Hari_Kishore_Reddy_Resume.docx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white overflow-x-hidden">
      {/* Custom Cursor */}
      <div 
        className="fixed w-6 h-6 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full pointer-events-none z-50 mix-blend-difference transition-transform duration-150 ease-out"
        style={{
          left: mousePosition.x - 12,
          top: mousePosition.y - 12,
          transform: 'scale(1)',
        }}
      />

      {/* Navigation */}
      <nav className="fixed top-0 w-full z-40 bg-black/20 backdrop-blur-lg border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Hari Kishore Reddy
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#home" className="hover:text-purple-400 transition-colors duration-300">Home</a>
              <a href="#about" className="hover:text-purple-400 transition-colors duration-300">About</a>
              <a href="#projects" className="hover:text-purple-400 transition-colors duration-300">Projects</a>
              <a href="#contact" className="hover:text-purple-400 transition-colors duration-300">Contact</a>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="md:hidden mt-4 pb-4 space-y-4">
              <a href="#home" className="block hover:text-purple-400 transition-colors duration-300">Home</a>
              <a href="#about" className="block hover:text-purple-400 transition-colors duration-300">About</a>
              <a href="#projects" className="block hover:text-purple-400 transition-colors duration-300">Projects</a>
              <a href="#contact" className="block hover:text-purple-400 transition-colors duration-300">Contact</a>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20">
        {/* Animated Background */}
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>

        <div className="text-center z-10 max-w-6xl mx-auto px-6">
          {/* Profile Photo */}
          <div className="mb-8 flex justify-center">
            <div className="relative">
              <div className="w-48 h-48 md:w-64 md:h-64 rounded-full overflow-hidden border-4 border-gradient-to-r from-purple-400 to-pink-400 p-1 bg-gradient-to-r from-purple-400 to-pink-400">
                <img
                  src="/profile photo kishore - Copy.png"
                  alt="Hari Kishore Reddy"
                  className="w-full h-full object-cover rounded-full bg-white"
                />
              </div>
              <div className="absolute -inset-4 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full blur opacity-30 animate-pulse"></div>
            </div>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-white via-purple-200 to-pink-200 bg-clip-text text-transparent animate-fade-in">
            Hari Kishore Reddy K
          </h1>
          <h2 className="text-2xl md:text-3xl font-semibold mb-6 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            Electrical & Electronics Engineer
          </h2>
          <p className="text-lg md:text-xl text-gray-300 mb-8 leading-relaxed max-w-4xl mx-auto">
            Aspiring Electrical and Electronics Engineer with expertise in renewable energy systems, 
            IoT development, and power systems optimization. Passionate about innovation and sustainable technology solutions.
          </p>
          
          {/* Contact Info */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8 text-sm md:text-base">
            <div className="flex items-center gap-2">
              <Mail size={16} className="text-purple-400" />
              <span>harikishorereddy9908@gmail.com</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone size={16} className="text-purple-400" />
              <span>+91-8019519353</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin size={16} className="text-purple-400" />
              <span>Andhra Pradesh, India</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}
              className="group px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full font-semibold hover:from-purple-700 hover:to-pink-700 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl"
            >
              View Projects
              <ChevronRight className="inline ml-2 group-hover:translate-x-1 transition-transform duration-300" size={20} />
            </button>
            <button 
              onClick={handleDownloadResume}
              className="px-8 py-4 border-2 border-purple-400 rounded-full font-semibold hover:bg-purple-400 hover:text-black transition-all duration-300 transform hover:scale-105 flex items-center gap-2 justify-center"
            >
              <Download size={16} />
              Download Resume
            </button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-6 bg-black/20">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              About Me
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="text-lg text-gray-300 leading-relaxed space-y-4">
                <p>
                  I'm a dedicated Electrical and Electronics Engineering student at Annamacharya Institute of Technology and Sciences, 
                  with a strong academic record (CGPA: 8.5) and a passion for renewable energy and sustainable technology solutions.
                </p>
                <p>
                  My expertise spans across power systems, renewable energy integration, IoT development, and embedded systems. 
                  I have hands-on experience in PCB design, energy optimization, and smart monitoring systems.
                </p>
                <p>
                  I'm actively seeking opportunities to apply my technical skills and contribute to innovative projects 
                  in the field of electrical engineering and renewable energy systems.
                </p>
              </div>

              {/* Skills */}
              <div className="space-y-4">
                <h3 className="text-2xl font-bold text-purple-400">Technical Skills</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold">Programming</h4>
                    <div className="flex flex-wrap gap-2">
                      <span className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm">Java</span>
                      <span className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm">SQL</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold">Engineering Tools</h4>
                    <div className="flex flex-wrap gap-2">
                      <span className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm">PCB Design</span>
                      <span className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm">IoT Systems</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-8">
              {/* Education */}
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6">
                <h3 className="text-2xl font-bold text-purple-400 mb-4">Education</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold">B.Tech in Electrical & Electronics Engineering</h4>
                    <p className="text-gray-300">Annamacharya Institute of Technology and Sciences</p>
                    <p className="text-sm text-purple-300">CGPA: 8.5 | Expected: 2025</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Intermediate (10+2)</h4>
                    <p className="text-gray-300">Sri Chaitanya Junior College, Tirupati</p>
                    <p className="text-sm text-purple-300">97.5% | 2021</p>
                  </div>
                </div>
              </div>

              {/* Certifications */}
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6">
                <h3 className="text-2xl font-bold text-purple-400 mb-4">Certifications</h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                    <span>PCB Designing and Fabrication - Magrita Tech</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                    <span>IoT-Based Smart Quality Monitoring System - CGR Meet</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Featured Projects
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              A showcase of my engineering projects spanning renewable energy, IoT systems, and software development
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg'
                    : 'bg-white/10 text-gray-300 hover:bg-white/20 hover:text-white'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Projects Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
            {filteredProjects.map((project, index) => (
              <div
                key={project.id}
                className="group relative bg-white/5 backdrop-blur-sm rounded-2xl overflow-hidden hover:bg-white/10 transition-all duration-500 transform hover:scale-105 hover:shadow-2xl"
                style={{
                  animationDelay: `${index * 100}ms`,
                }}
              >
                <div className="relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    {project.demoUrl && (
                      <button className="p-2 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-colors duration-300">
                        <ExternalLink size={16} />
                      </button>
                    )}
                    {project.githubUrl && (
                      <button className="p-2 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-colors duration-300">
                        <Github size={16} />
                      </button>
                    )}
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="text-sm text-purple-400 mb-2">{project.category}</div>
                  <h3 className="text-xl font-bold mb-3 group-hover:text-purple-400 transition-colors duration-300">
                    {project.title}
                  </h3>
                  <p className="text-gray-300 mb-4 leading-relaxed">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-6 bg-black/20">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-5xl font-bold mb-8 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            Let's Connect
          </h2>
          <p className="text-xl text-gray-300 mb-12">
            I'm always open to discussing new opportunities and innovative projects in electrical engineering.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="p-6 bg-white/5 backdrop-blur-sm rounded-2xl hover:bg-white/10 transition-colors duration-300">
              <Mail className="w-8 h-8 text-purple-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Email</h3>
              <p className="text-gray-300">harikishorereddy9908@gmail.com</p>
            </div>
            <div className="p-6 bg-white/5 backdrop-blur-sm rounded-2xl hover:bg-white/10 transition-colors duration-300">
              <Phone className="w-8 h-8 text-purple-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Phone</h3>
              <p className="text-gray-300">+91-8019519353</p>
            </div>
            <div className="p-6 bg-white/5 backdrop-blur-sm rounded-2xl hover:bg-white/10 transition-colors duration-300">
              <MapPin className="w-8 h-8 text-purple-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Location</h3>
              <p className="text-gray-300">Andhra Pradesh, India</p>
            </div>
          </div>

          <button className="px-12 py-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full font-semibold text-lg hover:from-purple-700 hover:to-pink-700 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl">
            Get In Touch
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-white/10">
        <div className="max-w-7xl mx-auto text-center text-gray-400">
          <p>&copy; 2024 Hari Kishore Reddy K. All rights reserved.</p>
          <p className="mt-2 text-sm">Aspiring Electrical & Electronics Engineer | Renewable Energy Enthusiast</p>
        </div>
      </footer>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 p-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-110 z-40"
        >
          <ArrowUp size={20} />
        </button>
      )}
    </div>
  );
}

export default App;